Track chain editor icons
========================

Resolved 29 / 29 BinaryData SVG symbols.

file | BinaryData | folder | use
--------------------------------------------------------------------------------
assets/icons/analysis/postfx.svg | postfx_svg | 01_header_toolbar | Show/hide post-FX panel
assets/icons/general/master_off.svg | master_off_svg | 01_header_toolbar | Mute: muted (speaker off)
assets/icons/general/master_on.svg | master_on_svg | 01_header_toolbar | Mute: audible (speaker on)
assets/icons/general/power.svg | power_svg | 01_header_toolbar | Chain / device / row bypass (power)
assets/icons/general/solo.svg | solo_svg | 01_header_toolbar | Track solo
assets/icons/knob/knob.svg | knob_svg | 01_header_toolbar | Toggle global macros panel
assets/icons/trackchain/gain-staging.svg | gainstaging_svg | 01_header_toolbar | Start/stop gain-staging pass
assets/icons/trackchain/icon-levels-boldm.svg | iconlevelsboldm_svg | 01_header_toolbar | Toggle post-FX levels meter
assets/icons/trackchain/icon-mods-boldm.svg | iconmodsboldm_svg | 01_header_toolbar | Toggle global modulators panel
assets/icons/trackchain/icon-presets-round-boldm.svg | iconpresetsroundboldm_svg | 01_header_toolbar | MAGDA track/device presets menu
assets/icons/trackchain/icon-racks-boldm.svg | iconracksboldm_svg | 01_header_toolbar | Add rack
assets/icons/trackchain/icon-spectrum-boldm.svg | iconspectrumboldm_svg | 01_header_toolbar | Toggle post-FX spectrum analyzer
assets/icons/trackchain/icon-treeview-boldm.svg | icontreeviewboldm_svg | 01_header_toolbar | Open chain tree dialog
assets/icons/trackchain/oscilloscope3.svg | oscilloscope3_svg | 01_header_toolbar | Toggle post-FX oscilloscope
assets/icons/IO/multiout.svg | multiout_svg | 02_device_slots | Multi-output routing
assets/icons/ai/ai.svg | ai_svg | 02_device_slots | Open AI panel on device slot
assets/icons/fontaudio/fad-logo-tracktion.svg | fadlogotracktion_svg | 02_device_slots | Tracktion-hosted device badge
assets/icons/general/compare.svg | compare_svg | 02_device_slots | MIDI thru toggle
assets/icons/general/copy.svg | copy_svg | 02_device_slots | Export/copy pattern as MIDI clip
assets/icons/general/learn.svg | learn_svg | 02_device_slots | MIDI learn
assets/icons/general/open_in_new.svg | open_in_new_svg | 02_device_slots | Open device UI window
assets/icons/general/random.svg | random_svg | 02_device_slots | Randomize step-sequencer pattern
assets/icons/general/sidechain.svg | sidechain_svg | 02_device_slots | Sidechain source selector
assets/icons/transport/record_circle.svg | record_circle_svg | 02_device_slots | Step-record mode
assets/icons/general/chord.svg | chord_svg | 03_other | Chord-track audition control
assets/icons/general/monitor_off.svg | monitor_off_svg | 03_other | Input monitor off
assets/icons/general/monitor_on.svg | monitor_on_svg | 03_other | Input monitor on
assets/icons/general/speaker.svg | speaker_svg | 03_other | 
assets/icons/general/speaker_simple.svg | speaker_simple_svg | 03_other | 
